from django.urls import path
from shop.views import index,details


urlpatterns = [
    path('' , index , name='index'),
    path('<int:myid>/', details, name='details'),]