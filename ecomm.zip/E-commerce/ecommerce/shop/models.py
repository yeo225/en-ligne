from django.db import models

# Create your models here.

class category(models.Model):
    name = models.CharField(max_length=80)
    date_added = models.DateField(auto_now_add=True)

    class Meta :
        ordering = ['-date_added']

    def __str__(self):
        return self.name

class Product(models.Model):
    title = models.CharField(max_length=80)
    price= models.FloatField()
    description = models.TextField()
    category = models.ForeignKey(category, related_name='categorie', on_delete=models.CASCADE)
    image = models.CharField(max_length=5000)       
    date_added = models.DateField(auto_now_add=True)

    class Meta :
        ordering = ['-date_added']

    def __str__(self):
        return self.title    

class user(models.Model):
    name = models.CharField(max_length=80)
    email = models.CharField(max_length=80)
    password = models.CharField(max_length=80)

    def __str__(self):
        return self.name

       
