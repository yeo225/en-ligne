from django.shortcuts import render
from .models import Product 
from django.core.paginator import Paginator

# Create your views here.
def index(request):
    product_object = Product.objects.all()
    category = Product.objects.values('category').distinct()
    # recherche par titre
    item_name = request.GET.get('item-name')
    if item_name != '' and item_name is not None:
        product_object = Product.objects.filter(title__icontains=item_name)

    # Pagination: 3 items per page
    paginator = Paginator(product_object, 12)
    page = request.GET.get('page')
    product_object = paginator.get_page(page)
    print ( product_object )

    # retourne a la page index.html avec la variable product_object
    return render(request , 'shop/index.html',{'product_object':product_object , 'category':category})

# def details(request):

def details(request, myid):

    # recupere tous les objets dans la table product
    product_object= Product.objects.get(id=myid)
    
    # retourne la page details.html avec la variable product_object
    return render(request , 'shop/details.html',{'product':product_object})


