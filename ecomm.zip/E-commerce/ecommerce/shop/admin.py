from django.contrib import admin
from .models import category, Product ,  user


class AdminCategory(admin.ModelAdmin):
    list_display = ('name' , 'date_added')

class AdminProduct(admin.ModelAdmin):
    list_display = ('title' , 'price' , 'category' , 'date_added')

# Register your models here.
admin.site.register(category , AdminCategory)
admin.site.register(Product  , AdminProduct) 
admin.site.register(user)